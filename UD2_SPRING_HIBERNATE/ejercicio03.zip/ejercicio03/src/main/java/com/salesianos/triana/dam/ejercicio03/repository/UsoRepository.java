package com.salesianos.triana.dam.ejercicio03.repository;

import com.salesianos.triana.dam.ejercicio03.model.Uso;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsoRepository extends JpaRepository<Uso, Long> {
}
