package com.salesianos.triana.dam.ejercicio03.repository;

import com.salesianos.triana.dam.ejercicio03.model.Estacion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EstacionRepository extends JpaRepository<Estacion, Long> {
}
