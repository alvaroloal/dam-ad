package com.salesianos.triana.dam.ejercicio03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
