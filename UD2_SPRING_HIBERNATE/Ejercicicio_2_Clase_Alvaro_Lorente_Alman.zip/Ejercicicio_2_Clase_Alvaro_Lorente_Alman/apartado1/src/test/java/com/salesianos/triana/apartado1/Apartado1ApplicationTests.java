package com.salesianos.triana.apartado1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Apartado1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
