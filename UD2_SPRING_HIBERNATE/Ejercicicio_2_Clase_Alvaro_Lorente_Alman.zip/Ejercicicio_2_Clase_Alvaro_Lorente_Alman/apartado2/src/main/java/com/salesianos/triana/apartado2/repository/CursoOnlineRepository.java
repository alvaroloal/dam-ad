package com.salesianos.triana.apartado2.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CursoOnlineRepository extends JpaRepository <CursoOnlineRepository, Long> {
}
